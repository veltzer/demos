Please copy the jWebSocketServer-Bundle.jar file into Tomcat's /lib folder to make it accessible 
to your web applications and copy the jWebSocket.xml configuration file in Tomcat's /conf folder.
