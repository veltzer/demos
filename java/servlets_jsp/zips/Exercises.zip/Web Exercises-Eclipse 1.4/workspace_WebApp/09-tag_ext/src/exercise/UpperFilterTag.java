package exercise;



import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.io.*;
/**
 *
 * @author  rank
 * @version
 */
public class UpperFilterTag extends BodyTagSupport {
    
    /**
     * Enter you code here
     */
    
}
